// File disiapkan untuk modularisasi tahap berikutnya.
// Untuk saat ini seluruh JavaScript asli tetap berada di app.js agar fitur tidak rusak.
