/* =======================================================
           SPA ROUTER & INITIALIZATION
           ======================================================= */
        function handleRoute() {
            const hash = window.location.hash || '#store';
            const storeApp = document.getElementById('storeApp');
            const adminApp = document.getElementById('adminApp');
            const body = document.getElementById('appBody');

            if (hash === '#admin') {
                storeApp.classList.add('hidden');
                adminApp.classList.remove('hidden');
                body.className = "bg-slate-50 text-slate-800 antialiased min-h-screen transition-colors duration-300";
                
                refreshAllUI();
                if(!revenueChartInstance) initCharts();
                const today = new Date().toISOString().split('T')[0];
                document.getElementById('posDeliveryDate').value = today;
            } else {
                adminApp.classList.add('hidden');
                storeApp.classList.remove('hidden');
                body.className = "text-slate-800 antialiased relative bg-[#fafafa] transition-colors duration-300";
                
                renderCatalog('Semua');
                renderBuilderOptions();
                calculateCustomPrice();
            }
            window.scrollTo(0,0);
        }

        window.addEventListener('hashchange', handleRoute);

        window.addEventListener('DOMContentLoaded', () => {
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            document.getElementById('checkoutDate').min = tomorrow.toISOString().split('T')[0];

            setInterval(() => {
                const now = new Date();
                document.getElementById('liveClock').innerText = now.toLocaleTimeString('id-ID');
            }, 1000);

            document.getElementById('mobileMenuBtn').addEventListener('click', () => {
                document.getElementById('navMenu').classList.toggle('hidden');
            });
            
            handleRoute();
        });

        /* =======================================================
           SHARED UTILITIES & FORMATTING
           ======================================================= */
        const formatRp = (val) => 'Rp ' + Number(val).toLocaleString('id-ID');

        /* =======================================================
           STOREFRONT & SHARED CATALOG LOGIC
           ======================================================= */
        const DEFAULT_CATALOG = [
            { id: 'PRD-1', name: 'Birthday Sunshine', category: 'Ulang Tahun', price: 180000, desc: 'Buket bunga matahari ceria untuk hari spesial.', img: 'https://placehold.co/400x400/fef08a/854d0e?text=Buket+Matahari+Ultah', tag: 'Populer' },
            { id: 'PRD-2', name: 'Sweet 17 Pink Roses', category: 'Ulang Tahun', price: 250000, desc: 'Rangkaian mawar pink pastel lembut.', img: 'https://placehold.co/400x400/fbcfe8/db2777?text=Mawar+Pink+Ultah', tag: '' },
            { id: 'PRD-4', name: 'Graduation Bear & Roses', category: 'Wisuda', price: 285000, desc: 'Buket mawar dilengkapi boneka teddy wisuda.', img: 'https://placehold.co/400x400/bfdbfe/1d4ed8?text=Boneka+Wisuda+%2B+Mawar', tag: 'Best Seller' },
            { id: 'PRD-7', name: 'Endless Love Red Roses', category: 'Anniversary', price: 450000, desc: '20 tangkai mawar merah marun super premium.', img: 'https://placehold.co/400x400/fecdd3/be123c?text=Mawar+Merah+Anniv', tag: 'Premium' },
        ];

        let catalogProducts = JSON.parse(localStorage.getItem('roos_catalog_products')) || DEFAULT_CATALOG;

        const builderFlowers = [
            { id: 'F1', name: 'Mawar Merah', price: 15000, img: 'https://placehold.co/100/fecdd3/be123c?text=Mawar+Merah' },
            { id: 'F2', name: 'Mawar Putih', price: 16000, img: 'https://placehold.co/100/f1f5f9/64748b?text=Mawar+Putih' },
            { id: 'F3', name: 'Mawar Pink', price: 16000, img: 'https://placehold.co/100/fbcfe8/db2777?text=Mawar+Pink' },
        ];

        const builderWraps = [
            { id: 'W1', name: 'Soft Pink', price: 20000, color: '#fbcfe8' },
            { id: 'W2', name: 'Classic White', price: 18000, color: '#f8fafc' },
            { id: 'W3', name: 'Elegant Black', price: 22000, color: '#1e293b' },
        ];

        let storeCart = [];
        let customState = { flowerId: 'F1', qty: 5, wrapId: 'W1', ribbonInfo: 'Satin Pink|15000' };
        const JASA_RANGKAI = 35000;

        function filterCategory(category) {
            document.querySelectorAll('.nav-kategori').forEach(btn => {
                if (btn.innerText === category) {
                    btn.classList.add('text-blush-500', 'font-semibold'); btn.classList.remove('text-slate-600', 'font-medium');
                } else {
                    btn.classList.remove('text-blush-500', 'font-semibold'); btn.classList.add('text-slate-600', 'font-medium');
                }
            });

            document.querySelectorAll('.pill-btn').forEach(btn => {
                if (btn.id === `pill-${category}`) {
                    btn.classList.replace('bg-white', 'bg-slate-800'); btn.classList.replace('text-slate-600', 'text-white');
                } else {
                    btn.classList.replace('bg-slate-800', 'bg-white'); btn.classList.replace('text-white', 'text-slate-600');
                }
            });

            document.getElementById('catalogTitle').innerText = category === 'Semua' ? 'Koleksi Semua Buket' : `Koleksi Buket ${category}`;
            const catalogSection = document.getElementById('katalog');
            window.scrollTo({top: catalogSection.getBoundingClientRect().top + window.pageYOffset - 80, behavior: 'smooth'});
            document.getElementById('mobileMenu').classList.add('hidden');
            renderCatalog(category);
        }

async function renderCatalog(category) {
    const grid = document.getElementById('productGrid');
    const emptyState = document.getElementById('emptyCatalog');

    if (!grid) return;

    grid.innerHTML = '';
    grid.classList.add('opacity-0');

    try {
        const response = await fetch('/roos-fleur/api/produk.php');

        if (!response.ok) {
            throw new Error('Gagal mengambil data produk');
        }

        const result = await response.json();

        if (!result.status || !result.data || !Array.isArray(result.data.produk)) {
            throw new Error('Format data produk tidak sesuai');
        }

        const apiProducts = Array.isArray(result.data.produk)
    ? result.data.produk
    : [];

const localProducts = JSON.parse(
    localStorage.getItem('roos_catalog_products') || '[]'
);

const normalizedLocalProducts = localProducts.map(p => ({
    ...p,

    id_produk: p.id_produk ?? p.id,
    nama_produk: p.nama_produk ?? p.name,
    kategori: p.kategori ?? p.category,
    harga: p.harga ?? p.price,
    deskripsi: p.deskripsi ?? p.desc,
    foto_url: p.foto_url ?? p.foto ?? p.image_url ?? p.image
}));

// Gabungkan data API + produk yang ditambahkan dari Admin
// Jika ID sama, data localStorage akan menjadi versi terbaru.
const productMap = new Map();

apiProducts.forEach(p => {
    productMap.set(String(p.id_produk ?? p.id), p);
});

normalizedLocalProducts.forEach(p => {
    productMap.set(String(p.id_produk ?? p.id), p);
});

const products = Array.from(productMap.values());

        const filtered = category === 'Semua'
            ? products
            : products.filter(p => p.kategori === category);

        if (filtered.length === 0) {
            grid.classList.add('hidden');

            if (emptyState) {
                emptyState.classList.remove('hidden');
            }

            return;
        }

        grid.classList.remove('hidden');

        if (emptyState) {
            emptyState.classList.add('hidden');
        }

        filtered.forEach(p => {
            let imageUrl = '';

            if (p.foto_url) {
                imageUrl = p.foto_url
                    .replace(/\\/g, '/');

                if (!imageUrl.startsWith('http') && !imageUrl.startsWith('/')) {
                    imageUrl = '/' + imageUrl;
                }
            }

            const imageHtml = imageUrl
                ? `<img src="${imageUrl}" alt="${p.nama_produk}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">`
                : `<div class="w-full h-full flex items-center justify-center bg-pink-50 text-pink-300 text-5xl">🌸</div>`;

            const price = Number(p.harga) || 0;

            grid.innerHTML += `
                <div class="group bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100 overflow-hidden">

                    <div class="relative overflow-hidden aspect-square bg-slate-50">

                        ${imageHtml}

                        <div class="absolute top-3 left-3 bg-white/90 text-pink-600 px-3 py-1 rounded-full text-xs font-bold">
                            ${p.kategori || 'Bunga'}
                        </div>

                        <button
                            onclick="addToStoreCart('${p.id_produk}', '${p.nama_produk}', ${price}, '${imageUrl}')"
                            class="absolute bottom-3 left-3 right-3 bg-white text-pink-600 font-bold py-3 rounded-xl shadow-lg hover:bg-pink-500 hover:text-white transition-all">
                            + Keranjang
                        </button>

                    </div>

                    <div class="p-5 flex flex-col">

                        <h3 class="font-bold text-lg text-slate-800 mb-2">
                            ${p.nama_produk}
                        </h3>

                        <p class="text-sm text-slate-500 mb-4 line-clamp-2">
                            ${p.deskripsi || 'Rangkaian bunga segar eksklusif untuk orang terkasih.'}
                        </p>

                        <div class="flex items-center justify-between mt-auto">

                            <span class="font-bold text-xl text-slate-900">
                                ${formatRp(price)}
                            </span>

                            <button
                                onclick="addToStoreCart('${p.id_produk}', '${p.nama_produk}', ${price}, '${imageUrl}')"
                                class="w-10 h-10 rounded-full bg-pink-500 text-white flex items-center justify-center hover:bg-pink-600 transition-all">
                                +
                            </button>

                        </div>

                    </div>

                </div>
            `;
        });

    } catch (error) {
        console.error('Gagal memuat katalog:', error);

        grid.innerHTML = `
            <div class="col-span-full text-center py-10">
                <p class="text-red-500 font-semibold">
                    Gagal memuat katalog produk.
                </p>
                <p class="text-slate-500 text-sm mt-2">
                    Pastikan server XAMPP dan API produk berjalan.
                </p>
            </div>
        `;
    }

    grid.classList.remove('opacity-0');
}
        function toggleMobileMenu() { document.getElementById('mobileMenu').classList.toggle('hidden'); }

        function renderBuilderOptions() {
            const fContainer = document.getElementById('builderFlowerOptions');
            if(!fContainer) return;
            fContainer.innerHTML = '';
            builderFlowers.forEach((f, idx) => {
                const isChecked = idx === 0 ? 'checked' : '';
                fContainer.innerHTML += `
                    <div class="relative">
                        <input type="radio" name="bFlower" id="${f.id}" value="${f.id}" class="peer hidden" onchange="updateCustomState('flowerId', '${f.id}')" ${isChecked}>
                        <label for="${f.id}" class="block cursor-pointer bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-blush-300 peer-checked:border-blush-500 peer-checked:ring-2 peer-checked:ring-blush-500 transition-all">
                            <img src="${f.img}" class="w-full h-16 object-cover">
                            <div class="p-2 text-center">
                                <p class="text-xs font-bold text-slate-700 truncate">${f.name}</p>
                                <p class="text-[10px] text-slate-500">${formatRp(f.price)}</p>
                            </div>
                        </label>
                    </div>
                `;
            });

            const wContainer = document.getElementById('builderWrapOptions');
            if(!wContainer) return;
            wContainer.innerHTML = '';
            builderWraps.forEach((w, idx) => {
                const isChecked = idx === 0 ? 'checked' : '';
                wContainer.innerHTML += `
                    <div class="relative flex flex-col items-center gap-1">
                        <input type="radio" name="bWrap" id="${w.id}" value="${w.id}" class="hidden radio-swatch" onchange="updateCustomState('wrapId', '${w.id}')" ${isChecked}>
                        <label for="${w.id}" class="w-10 h-10 rounded-full cursor-pointer shadow-inner border-2 border-white ring-2 ring-slate-200 transition-all block" style="background-color: ${w.color};"></label>
                        <span class="text-[10px] text-slate-500 font-medium">${w.name.split(' ')[0]}</span>
                    </div>
                `;
            });
        }

        function updateCustomQty(change) {
            let val = parseInt(document.getElementById('builderQty').value) + change;
            if(val < 1) val = 1; if(val > 50) val = 50;
            document.getElementById('builderQty').value = val;
            customState.qty = val; calculateCustomPrice();
        }

        function updateCustomState(key, val) { customState[key] = val; calculateCustomPrice(); }

        function calculateCustomPrice() {
            const ribbonEl = document.getElementById('builderRibbon');
            if(!ribbonEl) return {};
            customState.ribbonInfo = ribbonEl.value;
            const flower = builderFlowers.find(f => f.id === customState.flowerId);
            const wrap = builderWraps.find(w => w.id === customState.wrapId);
            const ribbonName = customState.ribbonInfo.split('|')[0];
            const ribbonPrice = parseInt(customState.ribbonInfo.split('|')[1]);
            const floralTotal = flower.price * customState.qty;
            const grandTotal = floralTotal + wrap.price + ribbonPrice + JASA_RANGKAI;

            document.getElementById('summaryFlowerName').innerText = flower.name;
            document.getElementById('summaryFlowerCalc').innerText = `${customState.qty} batang x ${formatRp(flower.price)}`;
            document.getElementById('summaryFlowerTotal').innerText = formatRp(floralTotal);
            document.getElementById('summaryWrapName').innerText = `Kertas: ${wrap.name}`;
            document.getElementById('summaryWrapPrice').innerText = formatRp(wrap.price);
            document.getElementById('summaryRibbonName').innerText = `Pita: ${ribbonName}`;
            document.getElementById('summaryRibbonPrice').innerText = formatRp(ribbonPrice);
            document.getElementById('summaryGrandTotal').innerText = formatRp(grandTotal);
            return { flower, wrap, ribbonName, ribbonPrice, grandTotal };
        }

        function addCustomToStoreCart() {
            const data = calculateCustomPrice();
            const item = {
                id: 'CSTM-' + Date.now(), name: `Custom: Buket ${data.flower.name}`,
                desc: `${customState.qty} Batang, Wrap ${data.wrap.name}, ${data.ribbonName}`,
                price: data.grandTotal, img: data.flower.img, isCustom: true
            };
            storeCart.push(item); updateStoreCartUI(); showStoreToast("Buket kustom berhasil ditambahkan ke keranjang!");
        }

        function addToStoreCart(id, name, price, img) {
            storeCart.push({ id, name, price, img, desc: 'Ready-made Bouquet', isCustom: false });
            updateStoreCartUI(); showStoreToast(`${name} berhasil ditambahkan!`);
        }

        function removeFromStoreCart(index) {
            storeCart.splice(index, 1); updateStoreCartUI();
        }

        function updateStoreCartUI() {
            const container = document.getElementById('storeCartItemsContainer');
            const badge = document.getElementById('cartBadge');
            const btnCheckout = document.getElementById('btnCheckout');
            if(!container) return;
            
            badge.innerText = storeCart.length;
            if (storeCart.length > 0) {
                badge.classList.remove('hidden'); document.getElementById('emptyCartMsg').classList.add('hidden');
                btnCheckout.removeAttribute('disabled');
            } else {
                badge.classList.add('hidden'); document.getElementById('emptyCartMsg').classList.remove('hidden');
                btnCheckout.setAttribute('disabled', 'true');
            }

            container.innerHTML = '';
            let subtotal = 0;
            storeCart.forEach((item, index) => {
                subtotal += item.price;
                container.innerHTML += `
                    <div class="flex gap-4 p-3 bg-white border border-slate-100 rounded-2xl shadow-sm relative group">
                        <div class="w-20 h-20 rounded-xl overflow-hidden bg-slate-50 flex-shrink-0"><img src="${item.img}" class="w-full h-full object-cover"></div>
                        <div class="flex-1 flex flex-col justify-center">
                            ${item.isCustom ? '<span class="text-[9px] font-bold text-blush-500 uppercase tracking-wider mb-1">Custom Order</span>' : ''}
                            <h4 class="font-bold text-sm text-slate-800 leading-tight">${item.name}</h4>
                            <p class="text-[10px] text-slate-500 line-clamp-2 mt-1">${item.desc}</p>
                            <span class="font-bold text-blush-600 text-sm mt-1">${formatRp(item.price)}</span>
                        </div>
                        <button onclick="removeFromStoreCart(${index})" class="absolute top-2 right-2 w-7 h-7 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-rose-500 hover:text-white">
                            <i class="fa-solid fa-trash-can text-xs"></i>
                        </button>
                    </div>
                `;
            });
            document.getElementById('storeCartSubtotalText').innerText = formatRp(subtotal);
            document.getElementById('storeCartTotalText').innerText = formatRp(subtotal + (storeCart.length>0?15000:0)); 
        }

        function toggleStoreCart() {
            const sidebar = document.getElementById('storeCartSidebar');
            const overlay = document.getElementById('storeOverlay');
            if (sidebar.classList.contains('hidden')) {
                sidebar.classList.remove('hidden'); overlay.classList.remove('hidden');
                setTimeout(() => { sidebar.classList.add('open'); overlay.classList.add('open'); }, 10);
            } else {
                sidebar.classList.remove('open'); overlay.classList.remove('open');
                setTimeout(() => { sidebar.classList.add('hidden'); overlay.classList.add('hidden'); }, 300);
            }
        }

        function openCheckout() {
            if(storeCart.length === 0) return;
            toggleStoreCart();
            setTimeout(() => {
                const modal = document.getElementById('checkoutModal');
                const overlay = document.getElementById('storeOverlay');
                modal.classList.remove('hidden'); overlay.classList.remove('hidden');
                setTimeout(() => { modal.classList.add('open'); overlay.classList.add('open'); }, 10);
            }, 350);
        }

        function closeStoreModals() {
            const sidebar = document.getElementById('storeCartSidebar');
            const checkout = document.getElementById('checkoutModal');
            const overlay = document.getElementById('storeOverlay');
            sidebar.classList.remove('open'); checkout.classList.remove('open'); overlay.classList.remove('open');
            setTimeout(() => { sidebar.classList.add('hidden'); checkout.classList.add('hidden'); overlay.classList.add('hidden'); }, 300);
        }

        function showStoreToast(msg) {
            const toast = document.getElementById('storefrontToast');
            document.getElementById('storeToastMsg').innerText = msg;
            toast.classList.remove('translate-y-20', 'opacity-0');
            setTimeout(() => { toast.classList.add('translate-y-20', 'opacity-0'); }, 3000);
        }

        function submitStoreOrder(e) {
            e.preventDefault();
            const btn = e.target.querySelector('button[type="submit"]');
            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Memproses...';
            btn.disabled = true;

            setTimeout(() => {
                const custName = document.getElementById('chkCustName').value;
                const totalAmt = storeCart.reduce((a, b) => a + b.price, 0) + 15000;
                const items = storeCart.map(i => i.name).join(', ');
                const selectedPayment = document.querySelector('input[name="paymentMethod"]:checked').value;
                const newOrder = {
                    id: 'WEB-' + Math.floor(1000 + Math.random() * 9000),
                    customerName: custName,
                    itemsSummary: items,
                    deliveryDate: document.getElementById('checkoutDate').value,
                    deliveryMethod: document.getElementById('chkDeliveryMethod').value,
                    paymentStatus: 'Lunas',
                    paymentMethod: selectedPayment,
                    status: 'Pending',
                    florist: 'Belum Ditugaskan',
                    total: totalAmt,
                    hpp: totalAmt * 0.45,
                    card: document.getElementById('chkGreetingCard').value || '-'
                };
                
                state.orders.unshift(newOrder);
                state.finance.unshift({ date: new Date().toISOString().split('T')[0], desc: `Penjualan Web: ${newOrder.id}`, type: 'IN', category: 'Penjualan Buket', amount: totalAmt });
                saveState();

                closeStoreModals();
                storeCart = [];
                updateStoreCartUI();
                showStoreToast("Pesanan Berhasil Dibuat di Roos & Fleur!");
                btn.innerHTML = originalText;
                btn.disabled = false;
                e.target.reset();
            }, 1200);
        }

        window.addEventListener('scroll', () => {
            const nav = document.getElementById('navbar');
            if(!nav) return;
            if (window.scrollY > 20) { nav.classList.add('shadow-md', 'bg-white/95'); nav.classList.remove('border-blush-100'); } 
            else { nav.classList.remove('shadow-md'); nav.classList.add('border-blush-100'); }
        });


        /* =======================================================
           ADMIN ERP LOGIC (Encapsulated)
           ======================================================= */
        const DEFAULT_INVENTORY = [
            { id: 'RAW-101', name: 'Mawar Merah Holland (Fresh)', category: 'Bunga Segar', qty: 120, cost: 7000, price: 15000, expiry: '2026-09-25' },
            { id: 'RAW-102', name: 'Mawar Putih Avalon', category: 'Bunga Segar', qty: 15, cost: 7500, price: 16000, expiry: '2026-09-24' },
            { id: 'WRAP-201', name: 'Kertas Cellophane Matte Pink', category: 'Wrapping Paper', qty: 50, cost: 3500, price: 8000, expiry: '-' }
        ];

        const DEFAULT_PRESETS = [
            { id: 'PRE-01', name: 'Romantic Velvet Rose Bouquet', price: 285000, hpp: 110000, desc: '10 Mawar Merah + Wrap Black Elegant' },
            { id: 'PRE-02', name: 'Pastel Dream Graduation Bouquet', price: 350000, hpp: 140000, desc: '8 Mawar Putih + Baby Breath' }
        ];

        const DEFAULT_SUPPLIERS = [
            { id: 'SUP-01', name: 'Kebun Bunga Segar Lembang', city: 'Bandung', leadTime: '1 Hari', items: 'Mawar, Lily, Krisan', rating: '4.9' }
        ];

        const DEFAULT_CUSTOMERS = [
            { id: 'CUST-001', name: 'Clarissa Valerie', phone: '081288990011', event: 'Ulang Tahun', eventDate: '2026-09-24', points: 120, totalSpend: 850000 }
        ];

        const DEFAULT_ORDERS = [
            { id: 'ORD-9011', customerName: 'Budi Santoso', itemsSummary: 'Romantic Velvet Rose Bouquet', deliveryDate: '2026-09-18', deliveryMethod: 'Kurir Toko', paymentStatus: 'Lunas', paymentMethod: 'QRIS', status: 'Dirangkai', florist: 'Siti', total: 285000, hpp: 110000, card: 'Happy Anniv!' }
        ];

        const DEFAULT_FINANCE = [
            { date: '2026-09-18', desc: 'Penjualan ORD-9011', type: 'IN', category: 'Penjualan', amount: 285000 }
        ];

        let state = {
            inventory: JSON.parse(localStorage.getItem('roos_inventory')) || DEFAULT_INVENTORY,
            orders: JSON.parse(localStorage.getItem('roos_orders')) || DEFAULT_ORDERS,
            suppliers: JSON.parse(localStorage.getItem('roos_suppliers')) || DEFAULT_SUPPLIERS,
            customers: JSON.parse(localStorage.getItem('roos_customers')) || DEFAULT_CUSTOMERS,
            finance: JSON.parse(localStorage.getItem('roos_finance')) || DEFAULT_FINANCE,
            cart: []
        };

        function saveState() {
            localStorage.setItem('roos_catalog_products', JSON.stringify(catalogProducts));
            localStorage.setItem('roos_inventory', JSON.stringify(state.inventory));
            localStorage.setItem('roos_orders', JSON.stringify(state.orders));
            localStorage.setItem('roos_suppliers', JSON.stringify(state.suppliers));
            localStorage.setItem('roos_customers', JSON.stringify(state.customers));
            localStorage.setItem('roos_finance', JSON.stringify(state.finance));
            if(window.location.hash === '#admin') refreshAllUI();
        }

        function resetDataDemo() {
            if(confirm("Reset seluruh data Roos & Fleur ke mode demo awal?")) {
                localStorage.clear();
                catalogProducts = [...DEFAULT_CATALOG];
                state.inventory = [...DEFAULT_INVENTORY]; state.orders = [...DEFAULT_ORDERS];
                state.suppliers = [...DEFAULT_SUPPLIERS]; state.customers = [...DEFAULT_CUSTOMERS];
                state.finance = [...DEFAULT_FINANCE]; state.cart = [];
                saveState(); showAdminToast("Data demo Roos & Fleur berhasil dimuat ulang!");
            }
        }

        function switchTab(tabId) {
            const tabs = ['dashboard', 'catalogadmin', 'pos', 'production', 'inventory', 'purchasing', 'crm', 'finance'];
            tabs.forEach(t => { const v = document.getElementById(t+'View'); if (v) v.classList.add('hidden'); });
            const targetView = document.getElementById(tabId + 'View');
            if(targetView) targetView.classList.remove('hidden');
            
            document.querySelectorAll('#adminApp .nav-btn').forEach(btn => {
                if (btn.dataset.tab === tabId) { btn.classList.add('bg-slate-800', 'text-white'); btn.classList.remove('text-slate-300'); } 
                else { btn.classList.remove('bg-slate-800', 'text-white'); btn.classList.add('text-slate-300'); }
            });

            const titles = { 
                dashboard: 'Dashboard Overview', 
                catalogadmin: 'Kelola Varian Buket & Katalog Online',
                pos: 'Point of Sales & Penjualan Buket', 
                production: 'Produksi & Papan Perakitan Florist', 
                inventory: 'Inventaris Stok Bunga', 
                purchasing: 'Pembelian & Supplier', 
                crm: 'Manajemen Pelanggan', 
                finance: 'Laporan Keuangan' 
            };
            document.getElementById('pageTitle').innerText = titles[tabId] || 'Roos & Fleur ERP';
            if(tabId === 'catalogadmin') renderAdminCatalogTable();
        }

        function refreshAllUI() {
            renderDashboardKPI(); renderRecentOrdersTable(); renderPOSOptionsAdmin(); renderOrdersTable();
            renderInventoryTable(); renderKanbanPipeline(); renderSuppliers(); renderCRMTable();
            renderFinanceTable(); updateAdminCartUI(); renderAdminCatalogTable();
        }

        function showAdminToast(msg) {
            const t = document.getElementById('adminToast');
            if(!t) return;
            document.getElementById('adminToastMsg').innerText = msg;
            t.classList.remove('translate-y-20', 'opacity-0');
            setTimeout(() => t.classList.add('translate-y-20', 'opacity-0'), 3000);
        }

        function closeAdminModal(id) { document.getElementById(id).classList.add('hidden'); }

        let revenueChartInstance = null;
        function renderDashboardKPI() {
            const totalRev = state.orders.reduce((acc, o) => acc + (o.total || 0), 0);
            document.getElementById('kpiRevenue').innerText = formatRp(totalRev);
            document.getElementById('kpiTodayOrders').innerText = state.orders.length;
            const pending = state.orders.filter(o => o.status === 'Pending' || o.status === 'Dirangkai').length;
            document.getElementById('kpiPendingProd').innerText = `${pending} Butuh Dirangkai`;
            document.getElementById('kpiCatalogCount').innerText = `${catalogProducts.length} Produk`;
            document.getElementById('kpiActiveStock').innerText = `${state.inventory.length} Items`;
            const lowStock = state.inventory.filter(i => i.qty <= 20).length;
            document.getElementById('kpiLowStockAlert').innerText = `⚠️ ${lowStock} Menipis`;
            
            const eventList = document.getElementById('dashboardEventList'); 
            if(eventList) {
                eventList.innerHTML = '';
                state.customers.slice(0, 3).forEach(c => {
                    eventList.innerHTML += `
                        <div class="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
                            <div><p class="font-bold text-slate-700">${c.name}</p><span class="text-[10px] text-slate-500">${c.event} - ${c.eventDate}</span></div>
                            <a href="https://wa.me/${c.phone}" target="_blank" class="px-2 py-1 bg-emerald-100 text-emerald-700 rounded font-bold text-[10px]">WA Remind</a>
                        </div>`;
                });
            }
        }

        function renderRecentOrdersTable() {
            const tbody = document.getElementById('recentOrdersTable'); 
            if(!tbody) return; 
            tbody.innerHTML = '';
            state.orders.slice(0, 5).forEach(o => {
                const colors = { 'Pending':'bg-amber-100 text-amber-700', 'Dirangkai':'bg-blue-100 text-blue-700', 'Siap':'bg-emerald-100 text-emerald-700', 'Dikirim':'bg-purple-100 text-purple-700', 'Selesai':'bg-slate-100 text-slate-700' };
                tbody.innerHTML += `
                    <tr class="hover:bg-slate-50">
                        <td class="p-4 font-bold text-rose-600">${o.id}</td><td class="p-4 font-semibold text-slate-800">${o.customerName}</td>
                        <td class="p-4 text-xs">${o.itemsSummary}</td><td class="p-4">${o.deliveryDate}</td>
                        <td class="p-4"><span class="px-2 py-1 rounded text-[10px] font-bold bg-slate-100">${o.paymentStatus}</span></td>
                        <td class="p-4"><span class="px-2.5 py-1 rounded-full text-[10px] font-bold ${colors[o.status]}">${o.status}</span></td>
                        <td class="p-4 text-right font-bold">${formatRp(o.total)}</td>
                    </tr>`;
            });
        }

        function initCharts() {
            const canvasEl = document.getElementById('revenueChart');
            if(!canvasEl) return;
            const ctx = canvasEl.getContext('2d');
            revenueChartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'],
                    datasets: [{ label: 'Pendapatan', data: [450, 680, 1200, 890, 1500, 2100, 1850], borderColor: '#f43f5e', backgroundColor: 'rgba(244, 63, 94, 0.1)', fill: true, tension: 0.3 }]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { ticks: { callback: v => 'Rp ' + v + 'k' } } } }
            });
        }

        /* --- ADMIN CATALOG & BUKET ADDITION (Real-Time Synchronized) --- */
        function openAddBouquetModal() {
            document.getElementById('bImgInput').value = 'https://images.unsplash.com/photo-1563241527-3004b7be0ffd?auto=format&fit=crop&w=800&q=80';
            document.getElementById('modalAddBouquet').classList.remove('hidden');
        }

        function useDummyPhoto() {
            // Menggunakan gambar bunga dumy 1.jpeg atau referensi visual yang sesuai
            document.getElementById('bImgInput').value = 'https://placehold.co/600x600/fbcfe8/be123c?text=Bunga+Dumy+1+Roos+%26+Fleur';
            showAdminToast("Foto referensi 'Bunga Dumy 1' diterapkan!");
        }

        function saveNewCatalogBouquet(e) {
            e.preventDefault();
            const name = document.getElementById('bNameInput').value;
            const category = document.getElementById('bCategoryInput').value;
            const price = parseFloat(document.getElementById('bPriceInput').value);
            const img = document.getElementById('bImgInput').value;
            const desc = document.getElementById('bDescInput').value;
            const tag = document.getElementById('bTagInput').value;

            const newProduct = {
                id: 'PRD-' + Date.now(),
                name: name,
                category: category,
                price: price,
                desc: desc,
                img: img,
                tag: tag
            };

            catalogProducts.unshift(newProduct);
            saveState();
            closeAdminModal('modalAddBouquet');
            renderAdminCatalogTable();
            showAdminToast(`Varian "${name}" berhasil ditambahkan & langsung tayang di web!`);
            e.target.reset();
        }

        function renderAdminCatalogTable() {
            const tbody = document.getElementById('adminCatalogTableBody');
            const search = (document.getElementById('adminCatalogSearch') || {value:''}).value.toLowerCase();
            if(!tbody) return;
            tbody.innerHTML = '';
            
            const filtered = catalogProducts.filter(p => p.name.toLowerCase().includes(search) || p.category.toLowerCase().includes(search));
            document.getElementById('adminCatalogCount').innerText = `Total ${catalogProducts.length} Varian`;

            filtered.forEach(p => {
                tbody.innerHTML += `
                    <tr class="hover:bg-slate-50 transition-colors">
                        <td class="p-3">
                            <img src="${p.img}" class="w-12 h-12 rounded-xl object-cover border border-slate-200" onerror="this.src='https://placehold.co/100x100/fbcfe8/db2777?text=Foto'">
                        </td>
                        <td class="p-3 font-bold text-slate-800">${p.name}</td>
                        <td class="p-3"><span class="px-2.5 py-1 bg-blush-50 text-blush-600 rounded-lg text-[11px] font-semibold">${p.category}</span></td>
                        <td class="p-3 font-bold text-rose-600">${formatRp(p.price)}</td>
                        <td class="p-3"><span class="px-2 py-0.5 bg-slate-100 rounded text-[10px] text-slate-600">${p.tag || '-'}</span></td>
                        <td class="p-3 text-right">
                            <button onclick="deleteCatalogBouquet('${p.id}')" class="px-2.5 py-1.5 bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white rounded-lg transition-colors" title="Hapus Varian">
                                <i class="fa-solid fa-trash-can"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        }

        function deleteCatalogBouquet(id) {
            if(confirm("Hapus varian buket ini dari katalog online Roos & Fleur?")) {
                catalogProducts = catalogProducts.filter(p => p.id !== id);
                saveState();
                renderAdminCatalogTable();
                showAdminToast("Varian buket berhasil dihapus!");
            }
        }

        function setPOSMode(mode) {
            if(mode === 'custom') {
                document.getElementById('customBouquetBuilderAdmin').classList.remove('hidden'); document.getElementById('presetBouquetCatalogAdmin').classList.add('hidden');
                document.getElementById('tabModeCustom').className = "flex-1 py-2 rounded-xl text-xs font-bold border border-rose-500 bg-rose-50 text-rose-600";
                document.getElementById('tabModePreset').className = "flex-1 py-2 rounded-xl text-xs font-bold border border-slate-200 bg-slate-50 text-slate-600";
            } else {
                document.getElementById('customBouquetBuilderAdmin').classList.add('hidden'); document.getElementById('presetBouquetCatalogAdmin').classList.remove('hidden');
                document.getElementById('tabModePreset').className = "flex-1 py-2 rounded-xl text-xs font-bold border border-rose-500 bg-rose-50 text-rose-600";
                document.getElementById('tabModeCustom').className = "flex-1 py-2 rounded-xl text-xs font-bold border border-slate-200 bg-slate-50 text-slate-600";
            }
        }

        function renderPOSOptionsAdmin() {
            const fSel = document.getElementById('posFlowerSelect'), wSel = document.getElementById('posWrapSelect'), rSel = document.getElementById('posRibbonSelect');
            if(!fSel) return;
            fSel.innerHTML = ''; wSel.innerHTML = ''; rSel.innerHTML = '';
            state.inventory.filter(i=>i.category==='Bunga Segar').forEach(f => fSel.innerHTML += `<option value="${f.id}">${f.name} - ${formatRp(f.price)}</option>`);
            state.inventory.filter(i=>i.category==='Wrapping Paper').forEach(w => wSel.innerHTML += `<option value="${w.id}">${w.name} - ${formatRp(w.price)}</option>`);
            state.inventory.filter(i=>i.category==='Pita & Aksesoris').forEach(r => rSel.innerHTML += `<option value="${r.id}">${r.name} - ${formatRp(r.price)}</option>`);

            const pCat = document.getElementById('presetBouquetCatalogAdmin'); 
            if(pCat) {
                pCat.innerHTML = '';
                catalogProducts.slice(0, 4).forEach(p => {
                    pCat.innerHTML += `
                        <div class="p-3 border rounded-xl bg-slate-50 flex flex-col justify-between">
                            <div><h4 class="font-bold text-xs">${p.name}</h4><p class="text-[10px] text-slate-500">${p.category}</p></div>
                            <div class="flex items-center justify-between mt-2"><span class="font-bold text-rose-600 text-xs">${formatRp(p.price)}</span>
                            <button onclick="addCatalogItemToAdminCart('${p.id}')" class="px-2 bg-rose-600 text-white rounded text-[10px]">+ Tambah</button></div>
                        </div>`;
                });
            }
            const cSel = document.getElementById('posCustomerSelect'); 
            if(cSel) {
                cSel.innerHTML = '';
                state.customers.forEach(c => cSel.innerHTML += `<option value="${c.name}">${c.name}</option>`);
            }
            calculateCustomHPPAdmin();
        }

        function addCatalogItemToAdminCart(id) {
            const p = catalogProducts.find(x => x.id === id);
            if(p) {
                state.cart.push({ id: p.id+'-'+Date.now(), name: p.name, details: p.category, price: p.price, hpp: p.price * 0.45, card: '-' });
                updateAdminCartUI();
                showAdminToast(`${p.name} ditambahkan ke kasir!`);
            }
        }

        function calculateCustomHPPAdmin() {
            const qtyEl = document.getElementById('posFlowerQty');
            if(!qtyEl) return 0;
            const fQty = parseInt(qtyEl.value)||1;
            const f = state.inventory.find(i=>i.id===document.getElementById('posFlowerSelect').value);
            const w = state.inventory.find(i=>i.id===document.getElementById('posWrapSelect').value);
            const r = state.inventory.find(i=>i.id===document.getElementById('posRibbonSelect').value);
            let hpp = (f?f.cost*fQty:0) + (w?w.cost:0) + (r?r.cost:0);
            const hppEl = document.getElementById('posCustomHPP');
            if(hppEl) hppEl.innerText = formatRp(hpp); 
            return hpp;
        }

        ['posFlowerSelect','posFlowerQty','posWrapSelect','posRibbonSelect'].forEach(id => {
            const el = document.getElementById(id); if(el) el.addEventListener('change', calculateCustomHPPAdmin);
        });

        function addCustomToAdminCart() {
            const fQty = parseInt(document.getElementById('posFlowerQty').value)||1;
            const f = state.inventory.find(i=>i.id===document.getElementById('posFlowerSelect').value);
            const w = state.inventory.find(i=>i.id===document.getElementById('posWrapSelect').value);
            if(!f || !w) return showAdminToast("Pilih komponen terlebih dahulu!");
            const hpp = calculateCustomHPPAdmin();
            state.cart.push({ id:'C-'+Date.now(), name:`Custom (${fQty}x ${f.name})`, details:`Wrap: ${w.name}`, price: Math.round((hpp*2.2)/5000)*5000, hpp:hpp, card:document.getElementById('posGreetingCard').value });
            updateAdminCartUI(); showAdminToast("Buket kustom ditambahkan ke kasir!");
        }

        function updateAdminCartUI() {
            const list = document.getElementById('adminCartItemsList'); if(!list) return; list.innerHTML = '';
            let subtotal = 0;
            state.cart.forEach((i, idx) => {
                subtotal += i.price;
                list.innerHTML += `
                    <div class="p-2 bg-slate-50 border rounded-xl flex justify-between text-xs items-center">
                        <div><h5 class="font-bold">${i.name}</h5><span class="font-bold text-rose-600">${formatRp(i.price)}</span></div>
                        <button onclick="state.cart.splice(${idx},1);updateAdminCartUI()" class="text-rose-500 hover:text-rose-700 px-2"><i class="fa-solid fa-trash"></i></button>
                    </div>`;
            });
            document.getElementById('adminCartSubtotal').innerText = formatRp(subtotal);
            document.getElementById('adminCartTotal').innerText = formatRp(subtotal + (state.cart.length?15000:0));
        }

        function clearAdminCart() { state.cart = []; updateAdminCartUI(); }

        function processAdminCheckout() {
            if(!state.cart.length) return showAdminToast("Keranjang kasir masih kosong!");
            const tot = state.cart.reduce((a,b)=>a+b.price,0)+15000;
            const order = {
                id: 'ORD-'+Math.floor(1000+Math.random()*9000), customerName: document.getElementById('posCustomerSelect').value,
                itemsSummary: state.cart.map(i=>i.name).join(', '), deliveryDate: document.getElementById('posDeliveryDate').value,
                deliveryMethod: document.getElementById('posDeliveryMethod').value, paymentStatus: document.getElementById('posPaymentStatus').value,
                paymentMethod: document.getElementById('posPaymentMethod').value, status: 'Pending', florist: '-', total: tot, hpp: state.cart.reduce((a,b)=>a+b.hpp,0), card: state.cart[0].card
            };
            state.orders.unshift(order);
            state.finance.unshift({ date: new Date().toISOString().split('T')[0], desc: `Penjualan POS ${order.id}`, type: 'IN', category: 'Penjualan', amount: tot });
            clearAdminCart(); saveState(); showAdminToast("Pesanan POS Berhasil Disimpan!");
        }

        function renderOrdersTable() {
            const tbody = document.getElementById('posAllOrdersTable'), search = (document.getElementById('orderSearchInput')||{value:''}).value.toLowerCase(), filter = (document.getElementById('orderStatusFilter')||{value:'ALL'}).value;
            if(!tbody) return; tbody.innerHTML = '';
            state.orders.filter(o => (o.customerName.toLowerCase().includes(search) || o.id.toLowerCase().includes(search)) && (filter==='ALL' || o.status===filter)).forEach(o => {
                tbody.innerHTML += `
                    <tr class="hover:bg-slate-50"><td class="p-3 font-bold text-rose-600">${o.id}</td><td class="p-3">${o.customerName}</td>
                    <td class="p-3">${o.itemsSummary}</td><td class="p-3"><span class="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-bold">${o.status}</span></td>
                    <td class="p-3"><span class="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded text-[10px] font-bold">${o.paymentStatus}</span></td>
                    <td class="p-3 text-right"><button onclick="deleteOrder('${o.id}')" class="text-rose-500 text-xs"><i class="fa-solid fa-trash"></i></button></td></tr>`;
            });
        }
        function deleteOrder(id) { if(confirm("Hapus pesanan ini?")) { state.orders = state.orders.filter(o=>o.id!==id); saveState(); showAdminToast("Pesanan dihapus"); } }

        /* KANBAN */
        function renderKanbanPipeline() {
            const cols = { 'Pending': document.getElementById('kanbanPending'), 'Dirangkai': document.getElementById('kanbanProgress'), 'Siap': document.getElementById('kanbanReady'), 'Dikirim': document.getElementById('kanbanDelivery') };
            Object.values(cols).forEach(c => { if(c) c.innerHTML = ''; });
            let counts = { 'Pending': 0, 'Dirangkai': 0, 'Siap': 0, 'Dikirim': 0 };

            state.orders.forEach(o => {
                const c = cols[o.status];
                if(c) {
                    counts[o.status]++;
                    c.innerHTML += `
                        <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-sm space-y-2">
                            <div class="flex justify-between"><span class="font-bold text-xs text-rose-600">${o.id}</span><span class="text-[10px] text-slate-400">${o.deliveryDate}</span></div>
                            <h5 class="font-bold text-xs">${o.customerName}</h5><p class="text-[11px]">${o.itemsSummary}</p>
                            <select onchange="updateOrderStatus('${o.id}', this.value)" class="text-[10px] p-1 border rounded bg-slate-50 outline-none w-full mt-2">
                                ${Object.keys(cols).map(s => `<option value="${s}" ${o.status===s?'selected':''}>${s}</option>`).join('')}
                                <option value="Selesai">Selesai</option>
                            </select>
                        </div>`;
                }
            });
            Object.keys(counts).forEach(k => {
                const el = document.getElementById('count' + (k==='Dirangkai'?'Progress':k));
                if(el) el.innerText = counts[k];
            });
        }
        function updateOrderStatus(id, status) {
            const o = state.orders.find(x=>x.id===id); if(o) { o.status = status; saveState(); showAdminToast(`Status diubah ke ${status}`); }
        }

        /* INVENTORY */
        let stockCatFilter = 'ALL';
        function filterStockCategory(cat) {
            stockCatFilter = cat;
            document.querySelectorAll('.stock-cat-btn').forEach(b => {
                if(b.innerText.includes(cat) || (cat==='ALL' && b.innerText.includes('Semua'))) b.className = "stock-cat-btn active px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-xl";
                else b.className = "stock-cat-btn px-4 py-2 bg-white text-slate-600 border border-slate-200 text-xs font-semibold rounded-xl";
            });
            renderInventoryTable();
        }
        function renderInventoryTable() {
            const tbody = document.getElementById('inventoryTableBody'), search = (document.getElementById('stockSearchInput')||{value:''}).value.toLowerCase();
            if(!tbody) return; tbody.innerHTML = '';
            const filtered = state.inventory.filter(i => (stockCatFilter==='ALL'||i.category===stockCatFilter) && i.name.toLowerCase().includes(search));
            document.getElementById('stockSummaryCount').innerText = `Menampilkan ${filtered.length} items`;
            filtered.forEach(i => {
                tbody.innerHTML += `<tr class="hover:bg-slate-50"><td class="p-4 font-mono text-xs">${i.id}</td><td class="p-4 font-bold">${i.name}</td>
                <td class="p-4"><span class="px-2 py-1 bg-slate-100 rounded text-[10px]">${i.category}</span></td><td class="p-4 font-bold ${i.qty<=20?'text-rose-600':''}">${i.qty}</td>
                <td class="p-4">${formatRp(i.cost)}</td><td class="p-4 font-bold text-emerald-600">${formatRp(i.price)}</td><td class="p-4">${i.expiry}</td>
                <td class="p-4 text-right"><button onclick="state.inventory=state.inventory.filter(x=>x.id!=='${i.id}');saveState()" class="text-rose-500"><i class="fa-solid fa-trash"></i></button></td></tr>`;
            });
        }
        function openNewStockModal() { document.getElementById('modalStock').classList.remove('hidden'); }
        function saveNewStock(e) {
            e.preventDefault();
            state.inventory.unshift({ id: 'RAW-'+Math.floor(100+Math.random()*900), name: document.getElementById('mStockName').value, category: document.getElementById('mStockCat').value, qty: parseInt(document.getElementById('mStockQty').value), cost: parseFloat(document.getElementById('mStockCost').value), price: parseFloat(document.getElementById('mStockPrice').value), expiry: '-' });
            closeAdminModal('modalStock'); saveState(); showAdminToast("Bahan baku ditambahkan!");
        }

        /* SUPPLIERS */
        function renderSuppliers() {
            const grid = document.getElementById('suppliersCardGrid'); if(!grid) return; grid.innerHTML = '';
            state.suppliers.forEach(s => grid.innerHTML += `<div class="bg-white p-5 rounded-2xl border"><h4 class="font-bold text-sm">${s.name}</h4><p class="text-xs text-slate-500">${s.city}</p></div>`);
            const sel = document.getElementById('mPOSupplier'); if(sel) { sel.innerHTML = ''; state.suppliers.forEach(s => sel.innerHTML += `<option>${s.name}</option>`); }
            
            const pBod = document.getElementById('poTableBody'); if(pBod) pBod.innerHTML = '';
        }
        function openPOModal() { document.getElementById('modalPO').classList.remove('hidden'); }
        function saveNewPO(e) {
            e.preventDefault();
            const amt = parseFloat(document.getElementById('mPOTotal').value);
            state.finance.unshift({ date: new Date().toISOString().split('T')[0], desc: `PO: ${document.getElementById('mPOItems').value}`, type: 'OUT', category: 'Bahan Baku', amount: amt });
            closeAdminModal('modalPO'); saveState(); showAdminToast("PO Dikirim & Kas Tercatat!");
        }

        /* CRM */
        function renderCRMTable() {
            const tbody = document.getElementById('crmTableBody'); if(!tbody) return; tbody.innerHTML = '';
            state.customers.forEach(c => tbody.innerHTML += `<tr><td class="p-3 font-bold">${c.name}</td><td class="p-3">${c.phone}</td><td class="p-3">${c.event}</td><td class="p-3 font-bold">${formatRp(c.totalSpend)}</td></tr>`);
            
            const rList = document.getElementById('crmReminderList'); if(rList) {
                rList.innerHTML = ''; state.customers.forEach(c => rList.innerHTML += `<div class="p-3 border rounded-xl bg-slate-50"><div class="flex justify-between text-xs font-bold"><span>${c.name}</span><span class="text-rose-600">${c.eventDate}</span></div></div>`);
            }
        }
        function openCustomerModal() { document.getElementById('modalCustomer').classList.remove('hidden'); }
        function saveCustomer(e) {
            e.preventDefault();
            state.customers.unshift({ id: 'CUST-'+Math.floor(100+Math.random()*900), name: document.getElementById('mCustName').value, phone: document.getElementById('mCustPhone').value, event: document.getElementById('mCustEventType').value, eventDate: document.getElementById('mCustEventDate').value, points:0, totalSpend:0 });
            closeAdminModal('modalCustomer'); saveState(); showAdminToast("Pelanggan disimpan!");
        }

        /* FINANCE */
        function renderFinanceTable() {
            const tbody = document.getElementById('financeTableBody'); if(!tbody) return; tbody.innerHTML = '';
            let tIn=0, tOut=0;
            state.finance.forEach(f => {
                if(f.type==='IN') tIn += f.amount; else tOut += f.amount;
                tbody.innerHTML += `<tr><td class="p-3">${f.date}</td><td class="p-3 font-bold">${f.desc}</td><td class="p-3"><span class="px-2 rounded text-[10px] ${f.type==='IN'?'bg-emerald-100 text-emerald-700':'bg-rose-100 text-rose-700'}">${f.type}</span></td><td class="p-3 text-right font-bold ${f.type==='IN'?'text-emerald-600':'text-rose-600'}">${formatRp(f.amount)}</td></tr>`;
            });
            document.getElementById('financeIncome').innerText = formatRp(tIn);
            document.getElementById('financeExpense').innerText = formatRp(tOut);
            document.getElementById('financeNetProfit').innerText = formatRp(tIn - tOut);
        }
        function openExpenseModal() { document.getElementById('modalExpense').classList.remove('hidden'); }
        function saveExpense(e) {
            e.preventDefault();
            state.finance.unshift({ date: new Date().toISOString().split('T')[0], desc: document.getElementById('mExpenseDesc').value, type: 'OUT', category: document.getElementById('mExpenseCat').value, amount: parseFloat(document.getElementById('mExpenseAmount').value) });
            closeAdminModal('modalExpense'); saveState(); showAdminToast("Pengeluaran dicatat!");
        }
